SPI ACADEMY V9 FINAL — STUDENT + ADMIN
============================================

What is included
----------------
1. Student portal: /student/
2. Admin portal: /admin/
3. Shared curriculum/question starter files
4. Supabase-ready database schema with Row Level Security
5. Central result storage and CSV export architecture
6. Bilingual English/Hindi test interface
7. Classes 6–12 and 11/12 Science, Commerce, Humanities structures
8. Separate grammar subjects
9. Chapter/Test A-B-C structure
10. WhatsApp result sharing
11. PWA manifest

IMPORTANT
---------
This package is production-ready in structure, but it is NOT a live hosted service yet.
A real secure central database needs your own Supabase project. No fake credentials are included.

SECURITY
--------
- Do NOT put a Supabase service_role key in the browser.
- The browser uses only the public anon key.
- Admin access is controlled by Supabase Auth + the profiles.role='admin' policy.
- The sample student_login RPC is intentionally disabled rather than storing plaintext passwords.
  For production student accounts, create Auth users/invites and map them to profiles.

DEPLOYMENT (FREE STATIC HOSTING OPTION)
---------------------------------------
You can host this folder on GitHub Pages, Netlify, Cloudflare Pages, etc.
After deployment the links will look like:
  https://YOUR-DOMAIN/student/
  https://YOUR-DOMAIN/admin/

SUPABASE SETUP
--------------
1. Create a Supabase project.
2. Open SQL Editor and run supabase/schema.sql.
3. Create your admin user in Authentication > Users.
4. Copy that user's UUID.
5. Insert/update the admin profile using:
   insert into public.profiles(id,role,name)
   values ('YOUR-UUID','admin','Deepak Sir')
   on conflict (id) do update set role='admin';
6. Copy Project URL and public anon key into shared/config.js.
7. Deploy the whole folder.

QUESTION BANK
-------------
The included questions.json is a starter bank. The system is designed for the admin to add/edit the complete
chapter-wise bank. Do not label these starter questions as official MPBSE papers.

STUDENT LINK
------------
Share /student/ with students.

ADMIN LINK
----------
Keep /admin/ for staff/admin use. It still requires secure authentication once Supabase is configured.

PLAY STORE
----------
The student portal can later be wrapped as an Android app with Capacitor/TWA. The admin portal is better kept
as a web dashboard for easy editing.
