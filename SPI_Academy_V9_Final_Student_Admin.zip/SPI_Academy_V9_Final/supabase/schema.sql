-- SPI Academy V9 Supabase schema
-- Run this in Supabase SQL Editor.
-- Never put a service_role key in browser code.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'student' check (role in ('admin','student')),
  student_id text unique,
  name text,
  class_no int check (class_no between 6 and 12),
  stream text,
  created_at timestamptz not null default now()
);

create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  class_no int not null check (class_no between 6 and 12),
  stream text,
  subject text not null,
  chapter text not null,
  test_code text not null default 'A' check (test_code in ('A','B','C')),
  question_en text not null,
  question_hi text not null,
  options_en jsonb not null,
  options_hi jsonb not null,
  answer_index int not null check (answer_index between 0 and 3),
  marks int not null default 1,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.results (
  id uuid primary key default gen_random_uuid(),
  student_id text not null,
  name text not null,
  class_no int not null check (class_no between 6 and 12),
  stream text,
  subject text not null,
  chapter text not null,
  test_code text not null,
  score int not null,
  total int not null,
  percentage numeric(5,2) not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.questions enable row level security;
alter table public.results enable row level security;

-- Helper: current user's role
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'); $$;

-- Students may read active questions; admins can manage all questions.
drop policy if exists "active questions readable" on public.questions;
create policy "active questions readable" on public.questions for select to authenticated using (active=true or public.is_admin());

drop policy if exists "admins insert questions" on public.questions;
create policy "admins insert questions" on public.questions for insert to authenticated with check (public.is_admin());

drop policy if exists "admins update questions" on public.questions;
create policy "admins update questions" on public.questions for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admins delete questions" on public.questions;
create policy "admins delete questions" on public.questions for delete to authenticated using (public.is_admin());

drop policy if exists "students insert own results" on public.results;
create policy "students insert own results" on public.results for insert to authenticated with check (student_id = (select student_id from public.profiles where id=auth.uid()) or public.is_admin());

drop policy if exists "admins read results" on public.results;
create policy "admins read results" on public.results for select to authenticated using (public.is_admin());

-- Secure student login RPC: passwords should be handled by Auth in a production student-account flow.
-- This demo RPC intentionally only returns a profile by student_id; the student app should be upgraded
-- to Supabase Auth accounts/invites for real password authentication.
create or replace function public.student_login(p_student_id text, p_password text)
returns table(student_id text, name text, class_no int, stream text)
language plpgsql security definer set search_path=public
as $$
begin
  -- Do not store plaintext passwords. This function is intentionally disabled until
  -- you implement Supabase Auth user accounts for students.
  return;
end;
$$;

-- Create your first admin through Supabase Authentication (email/password),
-- then run this after replacing the UUID:
-- insert into public.profiles(id,role,name) values ('AUTH-USER-UUID','admin','Deepak Sir')
-- on conflict (id) do update set role='admin';

-- Starter question import example can be done through the dashboard or a CSV import.
