SPI Academy Question Bank V2
--------------------------------
This package keeps the currently working GitHub Pages Student/Admin files and replaces questions.json
with an expanded bilingual NCERT/MP-board-aligned starter bank covering Classes 9-12 plus selected Class 11/12 streams.

IMPORTANT:
- This is an expanded starter bank, not a claim that every MP Board chapter/question has been exhaustively covered.
- Before academic/exam publication, questions should be reviewed by the teacher for the exact current MPBSE syllabus.
- Upload/replace the six root files only if you want the matching app package; the most important new file is questions.json.
- The current Admin page uses browser-local storage and is not secure production authentication.
